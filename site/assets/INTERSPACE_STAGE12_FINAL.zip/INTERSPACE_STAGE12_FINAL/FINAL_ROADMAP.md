# INTERSPACE — Frozen completion roadmap (Stages 9–12)

**Deliverable:** Reproducible, SI-unit, 3D ring-supported deployable impact-absorbing material system with explicit energy transport, harvesting, and uncertainty. The speculative free-standing interatomic-gap field is outside the verified scope.

## Stage 9: Deployment and activation
- Prescribed trajectory and inverse-dynamics reference; then actuator geometry, limits, collision/self-contact, buckling and deformation, controller scheduling.
- Metrics: deployment time, peak force/power, mechanical/electrical input work, residual strain, failed configurations.
- Gate: feasible actuator and power budget, deployment without self-intersection or numerical instability; mesh/time refinement.

## Stage 10: Spatial energy transport and ring recovery
- Arbitrary impact location, contact patch, wave travel to supports, compliant ring with finite displacement, reciprocal piezoelectric coupling, storage circuit and heat.
- Metrics: ring arrival times, impact/rebound/penetration, electrical storage energy, heat, peak force, conservation of energy and momentum including supports.
- Gate: audited balance; stable solution and distinguishable recovered energy versus resistive dissipation.

## Stage 11: Optimization and physical validation
- Match geometry/mass/material, compare flat, fixed dome and deployable dome; uncertainty, ablations, parameter sweeps, timestep/mesh convergence.
- At least one material-calibrated published benchmark or clearly label an unvalidated model; report negative results.
- Gate: reproducible benchmark and robust tradeoff curve, with physical constraints enforced.

## Stage 12: Engine freeze and portfolio release
- CLI/API, versioned configs, unit tests, documentation, reproducible figures and tables, limitations, and case study.
- Gate: clean-room rerun produces same results within specified numerical tolerances; no critical physics/accounting failures.

## Stop rule
No additional core stages after 12. Any unvalidated physical claims are documented as hypotheses. Failure to achieve an impact-stopping barrier is a valid result; no arbitrary parameter tuning to force success.
