import csv,json
from pathlib import Path
from dataclasses import replace
from interspace.transport3d import TransportConfig,run

def main():
    out=Path('results/stage10');out.mkdir(parents=True,exist_ok=True)
    cfg=TransportConfig()
    summary={}
    for name, c in [('pole',replace(cfg,impact_phi=0.0)),('off_axis',cfg),('off_axis_no_piezo',replace(cfg,coupling_N_per_V=0.0))]:
        r=run(c)
        with (out/f'{name}.csv').open('w',newline='') as f:
            w=csv.writer(f);w.writerow(r['columns']);w.writerows(r['history'])
        summary[name]={k:v for k,v in r.items() if k not in ('history','columns')}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
