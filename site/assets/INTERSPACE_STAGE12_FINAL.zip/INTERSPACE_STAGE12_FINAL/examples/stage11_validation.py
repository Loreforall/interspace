"""Run Stage 11 verification and feasibility audit (no calibration claim)."""
import json
from pathlib import Path
import numpy as np
from interspace.surface_contact import triangles,contact
from interspace.hemisphere import DomeConfig,mesh
from interspace.final_validation import deployment_scan,matched_study,CoupledConfig

def main():
    out=Path('results/stage11_final');out.mkdir(parents=True,exist_ok=True)
    checks=[]
    for sec in (12,24,48):
        cfg=DomeConfig(sectors=sec)
        pos,edges,rest,fixed=mesh(cfg);faces=triangles(cfg.rings,sec)
        # Normal contact at a point between nodes; surface-based contact responds
        # even when no vertex lies within the projectile radius.
        phi=.42;theta=.21
        surface=cfg.radius*np.array([np.sin(phi)*np.cos(theta),np.sin(phi)*np.sin(theta),np.cos(phi)])
        center=surface+surface/np.linalg.norm(surface)*(.9*cfg.projectile_radius)
        f,fp,u,h,overlap,fid=contact(pos,np.zeros_like(pos),faces,center,np.zeros(3),cfg.projectile_radius,cfg.contact_stiffness)
        checks.append({'sectors':sec,'faces':len(faces),'overlap_m':float(overlap),'force_N':float(np.linalg.norm(fp)),'net_contact_force_N':float(np.linalg.norm(f.sum(axis=0)+fp))})
    dep=deployment_scan()
    # Prior matched network comparisons are *sensitivity* only, not calibrated benchmarks.
    rows=matched_study(base=CoupledConfig(dome=DomeConfig(duration=.002,dt=2e-5)),sectors=(12,24),dt_factors=(1.,.5))
    data={'contact_refinement':checks,'deployment':dep,'matched_network_sensitivity':rows,'conclusions':{'continuous_surface_contact':'triangulated one-face penalty contact implemented and force-balanced; not full distributed contact','deployment':'prescribed actuator trajectory fails illustrative limits unless a feasible design is identified','mesh_convergence':'not established; angular resolution changes physical network stiffness and topology','material_calibration':'not established; material and actuator measurements needed','energy_storage':'idealized state-dependent conductance, not a calibrated rectifier or battery'}}
    (out/'validation.json').write_text(json.dumps(data,indent=2))
    print(json.dumps({'contact_cases':len(checks),'deployment_passes':sum(x['within_limits'] for x in dep),'comparison_cases':len(rows),'report':str(out/'validation.json')},indent=2))
if __name__=='__main__':main()
