"""Run passive vs prescribed-coupling experiments and save numerical diagnostics."""
import argparse,csv,json
from pathlib import Path
from dataclasses import replace
import numpy as np
from interspace.impact import ImpactConfig
from interspace.coupling import CouplingConfig,run_coupled

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',default='results/stage3')
    parser.add_argument('--stiffness',type=float,default=8.)
    parser.add_argument('--dt',type=float,default=.001)
    parser.add_argument('--duration',type=float,default=4.)
    args=parser.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    impact=ImpactConfig(dt=args.dt,duration=args.duration)
    summaries={}
    for name,k in [('passive',0.),('coupled',args.stiffness)]:
        records,summary,state=run_coupled(impact,replace(CouplingConfig(),stiffness=k))
        summaries[name]=summary
        with (out/f'{name}_history.csv').open('w',newline='') as fh:
            writer=csv.DictWriter(fh,fieldnames=records[0].keys());writer.writeheader();writer.writerows(records)
        np.savez_compressed(out/f'{name}_final.npz',positions=state.positions,velocities=state.velocities,bonds=state.bonds)
    (out/'comparison.json').write_text(json.dumps(summaries,indent=2))
    try:
        import matplotlib.pyplot as plt
        fig,axs=plt.subplots(3,1,figsize=(9,10),sharex=True)
        for name in summaries:
            with (out/f'{name}_history.csv').open() as fh: data=list(csv.DictReader(fh))
            t=np.array([float(r['time']) for r in data])
            for ax,key in zip(axs,['projectile_x','projectile_kinetic','energy_residual']):
                ax.plot(t,[float(r[key]) for r in data],label=name)
        for ax,label in zip(axs,['Projectile x','Projectile kinetic energy','Energy balance residual']):
            ax.set_ylabel(label);ax.legend();ax.grid(alpha=.25)
        axs[-1].set_xlabel('Dimensionless time');fig.tight_layout();fig.savefig(out/'comparison.png',dpi=150);plt.close(fig)
    except ImportError: pass
    print(json.dumps(summaries,indent=2))
if __name__=='__main__':main()
