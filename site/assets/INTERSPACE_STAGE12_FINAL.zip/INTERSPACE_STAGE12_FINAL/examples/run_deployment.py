from pathlib import Path
import json
import numpy as np
from interspace.deployment import simulate, DeploymentConfig

def main():
    r=simulate(DeploymentConfig())
    out=Path('results/stage9');out.mkdir(parents=True,exist_ok=True)
    np.savetxt(out/'deployment.csv',r['history'],delimiter=',',header=','.join(r['columns']),comments='')
    summary={k:v for k,v in r.items() if k in ('max_positive_power_W','max_sum_force_N','power_limit_pass','force_limit_pass','final_fraction','note')}
    summary['final_energy_residual_J']=float(r['history'][-1,-1])
    summary['positive_work_J']=float(r['history'][-1,5])
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
