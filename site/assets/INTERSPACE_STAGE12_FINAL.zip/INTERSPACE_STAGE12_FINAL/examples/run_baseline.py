"""Run baseline collision, save CSV and optional diagnostic plot."""
import argparse, csv, json
from pathlib import Path
import numpy as np
from interspace import make_lattice, simulate, Parameters

def run(output='results', dt=0.001, duration=3.0, speed=1.0, nx=8, ny=7):
    out = Path(output); out.mkdir(parents=True, exist_ok=True)
    params = Parameters()
    state = make_lattice(nx=nx, ny=ny, projectile_speed=speed, params=params)
    records, state = simulate(state, duration=duration, dt=dt, sample_every=max(1,round(.01/dt)), params=params)
    with (out/'diagnostics.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0])); writer.writeheader();writer.writerows(records)
    np.savez_compressed(out/'final_state.npz', positions=state.positions, velocities=state.velocities,
                        masses=state.masses,bonds=state.bonds)
    E=np.array([r['total_energy'] for r in records]); px=np.array([r['momentum_x'] for r in records]); py=np.array([r['momentum_y'] for r in records]);
    summary={'relative_energy_drift_max':float(np.max(np.abs(E-E[0]))/max(abs(E[0]),1)),
             'momentum_drift_max':float(np.max(np.hypot(px-px[0],py-py[0]))),
             'projectile_final_vx':records[-1]['projectile_vx'], 'samples':len(records),
             'units':'dimensionless; model is not calibrated to a material'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        t=[r['time'] for r in records]
        fig,axes=plt.subplots(3,1,figsize=(8,9),sharex=True)
        axes[0].plot(t,[r['projectile_x'] for r in records],label='Projectile x')
        axes[0].set_ylabel('Position');axes[0].legend()
        axes[1].plot(t,[r['kinetic'] for r in records],label='Kinetic')
        axes[1].plot(t,[r['potential'] for r in records],label='Potential')
        axes[1].plot(t,[r['total_energy'] for r in records],label='Total')
        axes[1].set_ylabel('Energy');axes[1].legend()
        axes[2].plot(t,(E-E[0])/max(abs(E[0]),1))
        axes[2].set_ylabel('Relative energy residual');axes[2].set_xlabel('Time')
        fig.tight_layout();fig.savefig(out/'diagnostics.png',dpi=160);plt.close(fig)
    except ImportError: pass
    print(json.dumps(summary,indent=2))
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',default='results');p.add_argument('--dt',type=float,default=.001)
    p.add_argument('--duration',type=float,default=3.);p.add_argument('--speed',type=float,default=1.)
    p.add_argument('--nx',type=int,default=8);p.add_argument('--ny',type=int,default=7)
    args=p.parse_args();run(**vars(args))
