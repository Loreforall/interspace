"""Run passive, harvesting and capacity-limited experiments."""
import csv,json,argparse
from pathlib import Path
from interspace.recovery import RecoveryConfig,run_recovery

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='results/stage5');args=ap.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    summary={}
    for name,opts in [('passive',dict(damping=0)),('harvesting',dict(damping=1.0,efficiency=.7)),('capacity_limited',dict(damping=1.0,efficiency=.7,capacity=.05))]:
        records,_=run_recovery(RecoveryConfig(**opts))
        with (out/f'{name}.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=records[0].keys());w.writeheader();w.writerows(records)
        summary[name]={k:records[-1][k] for k in ('projectile_ke','stored','heat','energy_residual','momentum_residual')}
        summary[name]['maximum_absolute_energy_residual']=max(abs(r['energy_residual']) for r in records)
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    try:
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(9,5))
        for name in summary:
            with (out/f'{name}.csv').open() as f: rows=list(csv.DictReader(f))
            ax.plot([float(r['time']) for r in rows],[float(r['projectile_ke']) for r in rows],label=name)
        ax.set(xlabel='Dimensionless time',ylabel='Projectile kinetic energy',title='Stage 5: passive vs dissipative interatomic coupling');ax.legend();fig.tight_layout();fig.savefig(out/'comparison.png',dpi=160);plt.close(fig)
    except ImportError: pass
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
