"""Run reproducible Stage 4 single-particle SI-field feasibility study."""
import csv,json,argparse
from dataclasses import replace
from pathlib import Path
import numpy as np
from interspace.field import FieldConfig, simulate_field, required_field_for_energy

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',default='results/stage4')
    args=ap.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    cfg=FieldConfig()
    cases={'field_off':replace(cfg,amplitude_v_m=0),'static_field':cfg,'ramped_field':replace(cfg,ramp_s=8e-12)}
    summaries={}
    for name,c in cases.items():
        rows,summary=simulate_field(c)
        summaries[name]=summary
        with (out/f'{name}.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    initial_ke=0.5*cfg.particle_mass_kg*cfg.initial_speed_m_s**2
    summaries['feasibility']={'field_for_well_depth_equal_to_kinetic_v_m':float(required_field_for_energy(cfg.alpha_si,initial_ke)),
                              'note':'Equality of attractive well depth and KE is NOT a stopping criterion'}
    (out/'summary.json').write_text(json.dumps(summaries,indent=2))
    try:
        import matplotlib;matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,axes=plt.subplots(2,1,figsize=(8,7),sharex=True)
        for name in cases:
            with (out/f'{name}.csv').open() as f: data=list(csv.DictReader(f))
            t=np.array([float(r['time_s']) for r in data])*1e12
            axes[0].plot(t,[float(r['x_m'])*1e9 for r in data],label=name)
            axes[1].plot(t,[float(r['kinetic_j'])/initial_ke for r in data],label=name)
        axes[0].set_ylabel('Position (nm)');axes[1].set_ylabel('Kinetic / initial kinetic');axes[1].set_xlabel('Time (ps)')
        axes[0].legend();axes[1].legend();fig.tight_layout();fig.savefig(out/'field_comparison.png',dpi=160);plt.close(fig)
    except ImportError: pass
    print(json.dumps(summaries,indent=2))
if __name__=='__main__':main()
