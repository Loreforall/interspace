import csv,json
from pathlib import Path
import numpy as np
from interspace.hemisphere import DomeConfig,run

def main():
    outdir=Path('results/stage8');outdir.mkdir(parents=True,exist_ok=True)
    result=run()
    with (outdir/'history.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(result['columns']);writer.writerows(result['history'])
    np.savez_compressed(outdir/'mesh.npz',initial=result['initial'],final=result['positions'],edges=result['edges'],fixed=result['fixed'])
    summary={k:v for k,v in result.items() if k in ('initial_energy_J','max_abs_energy_residual_J','note')}
    (outdir/'summary.json').write_text(json.dumps(summary,indent=2))
    try:
        import matplotlib.pyplot as plt
        h=result['history'];fig,ax=plt.subplots(3,1,figsize=(8,9),sharex=True)
        ax[0].plot(h[:,0],h[:,2]);ax[0].set_ylabel('Projectile velocity (m/s)')
        for idx in (3,4,5,6,7): ax[1].plot(h[:,0],h[:,idx],label=result['columns'][idx])
        ax[1].legend(fontsize=8);ax[1].set_ylabel('Energy (J)')
        ax[2].plot(h[:,0],h[:,8]);ax[2].set_ylabel('Energy residual (J)');ax[2].set_xlabel('Time (s)')
        fig.tight_layout();fig.savefig(outdir/'diagnostics.png',dpi=160);plt.close(fig)
    except ImportError: pass
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
