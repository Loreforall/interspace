"""Run Stage 10/11 verification study, saving JSON and CSV."""
import csv,json
from pathlib import Path
from dataclasses import replace
from interspace.final_validation import CoupledConfig, run, deployment_scan, matched_study
from interspace.hemisphere import DomeConfig

out=Path('results/final_validation');out.mkdir(parents=True,exist_ok=True)
base=CoupledConfig(dome=DomeConfig(rings=5,sectors=12,dt=1e-5,duration=.012))
rows=matched_study(base,sectors=(12,18),dt_factors=(1,.5),geometries=('flat','dome'),couplings=(0.,.004))
with (out/'matched_study.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
deploy=deployment_scan(times=(.08,.16,.32,.64))
with (out/'deployment_scan.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=deploy[0].keys());w.writeheader();w.writerows(deploy)
summary={'number_matched_runs':len(rows),'max_energy_residual_J':max(x['energy_residual_J'] for x in rows),'max_stored_J':max(x['stored_J'] for x in rows),'deployment_feasible_times_s':[x['activation_time_s'] for x in deploy if x['within_limits']], 'caveats':['Total free-node mass is held fixed across angular resolutions, but discrete edge stiffness and contact resolution are not renormalized.','Flat and dome use same node/edge count at each resolution, but do not have equal projected area or effective stiffness.','Impact is sphere-to-node penalty contact, not full continuous surface contact.','Energy storage uses idealized load conductance feedback, not a validated power electronics circuit.']}
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
