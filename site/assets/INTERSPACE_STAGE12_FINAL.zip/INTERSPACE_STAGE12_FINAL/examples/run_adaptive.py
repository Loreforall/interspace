"""Run three matched Stage 6 configurations; outputs CSV, JSON and PNG."""
import argparse,csv,json
from pathlib import Path
import numpy as np
from interspace.adaptive import AdaptiveConfig,run_adaptive

def run(output, duration=5.0):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    summaries={};series={}
    for mode in ('passive','fixed','adaptive'):
        rows,_=run_adaptive(AdaptiveConfig(mode=mode,duration=duration))
        series[mode]=rows
        with (output/f'{mode}.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
        pke=np.array([r['projectile_ke'] for r in rows]);vx=np.array([r['projectile_vx'] for r in rows]);x=np.array([r['projectile_x'] for r in rows]);
        summaries[mode]={'final_projectile_ke':float(pke[-1]),'final_stored':rows[-1]['stored'],
           'final_heat':rows[-1]['heat'],'final_projectile_x':float(x[-1]),
           'minimum_projectile_speed':float(np.min(np.abs(vx))),
           'maximum_projectile_x':float(np.max(x)),
           'maximum_energy_residual':float(max(abs(r['energy_residual']) for r in rows)),
           'maximum_momentum_residual':float(max(r['momentum_residual'] for r in rows))}
    (output/'summary.json').write_text(json.dumps(summaries,indent=2))
    try:
        import matplotlib.pyplot as plt
        fig,axes=plt.subplots(3,1,figsize=(9,10),sharex=True)
        for mode,rows in series.items():
            t=[r['time'] for r in rows]
            axes[0].plot(t,[r['projectile_vx'] for r in rows],label=mode)
            axes[1].plot(t,[r['stored'] for r in rows],label=mode)
            axes[2].plot(t,[r['damping'] for r in rows],label=mode)
        for ax,y in zip(axes,['Projectile x velocity','Stored energy','Controller command']):ax.set_ylabel(y);ax.grid(alpha=.2)
        axes[0].legend();axes[-1].set_xlabel('Dimensionless time');fig.tight_layout()
        fig.savefig(output/'comparison.png',dpi=140);plt.close(fig)
    except ImportError:pass
    return summaries

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',default='results/stage6');p.add_argument('--duration',type=float,default=5.0)
    a=p.parse_args();print(json.dumps(run(a.output,a.duration),indent=2))
