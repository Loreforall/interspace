"""Generate compact reproducible Stage 11 diagnostic study."""
import csv,json
from pathlib import Path
from interspace.hemisphere import DomeConfig
from interspace.transport3d import TransportConfig
from interspace.stage10_extended import StorageConfig,run
from interspace.stage11 import study,convergence_pairs

out=Path('results/stage11');out.mkdir(parents=True,exist_ok=True)
base=TransportConfig(dome=DomeConfig(rings=4,sectors=12,duration=.008,dt=1e-5))
rows=study(base,StorageConfig(efficiency=.75,capacity_J=1e-5),angles=(0.,.45,.75),couplings=(0.,.004,.008),dt_factors=(1.,.5))
with (out/'parameter_study.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
conv=convergence_pairs(rows)
with (out/'convergence.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=conv[0]);w.writeheader();w.writerows(conv)
example=run(base)
summary={'cases':len(rows),'max_energy_residual_J':max(x['max_energy_residual_J'] for x in rows),
 'max_storage_partition_residual_J':max(x['storage_residual_J'] for x in rows),
 'wave_arrival_by_ring_s':example['band_wave_arrival_s'],
 'wave_threshold_J':example['wave_threshold_J'],
 'max_velocity_dt_difference_m_s':max(x['velocity_difference_m_s'] for x in conv),
 'max_electrical_dt_difference_J':max(x['electrical_energy_difference_J'] for x in conv)}
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
