"""Run reproducible passive-impact experiments and produce plots/CSV."""
import argparse, csv, json
from pathlib import Path
import numpy as np
from interspace.impact import ImpactConfig,run_impact

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',default='results/stage2')
    p.add_argument('--duration',type=float,default=4.0)
    p.add_argument('--dt',type=float,default=.001)
    p.add_argument('--speed',type=float,default=1.0)
    p.add_argument('--defect-fraction',type=float,default=0.0)
    p.add_argument('--seed',type=int,default=0)
    args=p.parse_args()
    output=Path(args.output);output.mkdir(parents=True,exist_ok=True)
    cfg=ImpactConfig(duration=args.duration,dt=args.dt,speed=args.speed,
                     defect_fraction=args.defect_fraction,seed=args.seed)
    records,summary,state=run_impact(cfg)
    with (output/'history.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    (output/'summary.json').write_text(json.dumps({'config':vars(cfg),'summary':summary},indent=2))
    np.savez_compressed(output/'final_state.npz',positions=state.positions,velocities=state.velocities,bonds=state.bonds)
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        t=np.array([r['time'] for r in records]);fig,axes=plt.subplots(3,1,figsize=(9,9),sharex=True)
        for name in ['projectile_kinetic','lattice_kinetic']:
            axes[0].plot(t,[r[name] for r in records],label=name)
        axes[0].legend();axes[0].set_ylabel('Kinetic energy')
        axes[1].plot(t,[r['projectile_x'] for r in records],label='projectile x')
        axes[1].plot(t,[r['max_lattice_displacement'] for r in records],label='max lattice displacement')
        axes[1].legend();axes[1].set_ylabel('Position / displacement')
        e0=records[0]['total_energy'];axes[2].plot(t,[r['total_energy']-e0 for r in records]);axes[2].set_ylabel('Energy residual');axes[2].set_xlabel('Dimensionless time')
        fig.tight_layout();fig.savefig(output/'diagnostics.png',dpi=160);plt.close(fig)
    except ImportError: pass
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
