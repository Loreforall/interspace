"""Run physically dimensioned piezoelectric impact reference experiments."""
import csv, json
from pathlib import Path
from interspace.physical import PhysicalParameters,run

def main():
    outdir=Path('results/stage7');outdir.mkdir(parents=True,exist_ok=True)
    cases={'uncoupled':PhysicalParameters(coupling_n_v=0),
           'piezoelectric':PhysicalParameters(),
           'stronger_load':PhysicalParameters(resistance_ohm=1000)}
    summary={}
    for name,p in cases.items():
        r=run(p)
        summary[name]={k:r[k] for k in ('initial_energy_j','max_energy_residual_j','max_relative_energy_residual','harvest_fraction','heat_fraction')}
        with (outdir/f'{name}.csv').open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['time_s','compression_m','velocity_m_s','voltage_v','load_energy_j','internal_heat_j','released_heat_j','total_energy_j'])
            for t,y,e in zip(r['time_s'][::20],r['states'][::20],r['energy_j'][::20]):w.writerow([t,*y,e])
    (outdir/'summary.json').write_text(json.dumps(summary,indent=2))
    try:
        import matplotlib.pyplot as plt
        fig,axs=plt.subplots(3,1,figsize=(8,9),sharex=True)
        for name,p in cases.items():
            r=run(p);t=r['time_s'];s=r['states']
            axs[0].plot(t,s[:,0]*1000,label=name)
            axs[1].plot(t,s[:,2],label=name)
            axs[2].plot(t,s[:,3]*1000,label=name)
        for ax,ylabel in zip(axs,['Modal displacement (mm)','Voltage (V)','Load energy (mJ)']):ax.set_ylabel(ylabel);ax.grid(alpha=.25)
        axs[0].legend();axs[-1].set_xlabel('Time (s)');fig.tight_layout();fig.savefig(outdir/'comparison.png',dpi=150);plt.close(fig)
    except ImportError:pass
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
