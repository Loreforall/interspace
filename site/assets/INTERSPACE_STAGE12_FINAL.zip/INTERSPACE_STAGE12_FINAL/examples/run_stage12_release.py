"""Stage 12 engineering console: reproducible figures from the actual 3D solver."""
import argparse, csv, json
from pathlib import Path
import numpy as np
from interspace.hemisphere import DomeConfig, mesh, run

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='release/generated');args=ap.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    cfg=DomeConfig(); result=run(cfg,sample_every=4)
    data=result['history']; cols=result['columns']
    with (out/'stage12_baseline.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(cols);writer.writerows(data)
    summary={'config':vars(cfg),'initial_energy_J':result['initial_energy_J'],'max_abs_energy_residual_J':result['max_abs_energy_residual_J'],'final_projectile_velocity_m_s':float(data[-1,2]),'simulation_duration_s':float(data[-1,0]),'status':'illustrative numerical baseline; not physically calibrated'}
    (out/'baseline_summary.json').write_text(json.dumps(summary,indent=2))
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.tri import Triangulation
    fig=plt.figure(figsize=(16,9),facecolor='#101216')
    gs=fig.add_gridspec(3,4,left=.045,right=.985,top=.92,bottom=.08,hspace=.38,wspace=.33)
    def axstyle(ax):
        ax.set_facecolor('#151a20');ax.grid(True,alpha=.23,linewidth=.6)
        ax.tick_params(colors='#b9c4cc',labelsize=8)
        for s in ax.spines.values():s.set_color('#475569')
        ax.xaxis.label.set_color('#d4dce3');ax.yaxis.label.set_color('#d4dce3');ax.title.set_color('#e2e8f0')
    ax=fig.add_subplot(gs[:,0:2],projection='3d');ax.set_facecolor('#151a20')
    xyz=result['positions'];edges=result['edges']; fixed=result['fixed']
    for a,b in edges:ax.plot(*zip(xyz[a],xyz[b]),color='#42c8e8',alpha=.34,lw=.5)
    ax.scatter(xyz[~fixed,0],xyz[~fixed,1],xyz[~fixed,2],s=4,c='#fbbf24',alpha=.7)
    ax.scatter(xyz[fixed,0],xyz[fixed,1],xyz[fixed,2],s=12,c='#2dd4bf')
    ax.set(xlabel='X [m]',ylabel='Y [m]',zlabel='Z [m]',title='MESH / NODE NETWORK / DEFORMED')
    ax.set_box_aspect((1,1,.65));ax.view_init(elev=22,azim=36)
    ax.tick_params(labelsize=7,colors='#b9c4cc');ax.grid(True)
    t=data[:,0]*1000
    panels=[(gs[0,2],2,'PROJECTILE VELOCITY','v_z [m/s]'),(gs[0,3],3,'PROJECTILE KINETIC ENERGY','E [J]'),(gs[1,2],5,'ELASTIC ENERGY','U [J]'),(gs[1,3],7,'DISSIPATED ENERGY','Q [J]'),(gs[2,2],8,'ENERGY BALANCE RESIDUAL','r_E [J]'),(gs[2,3],9,'CONTACT OVERLAP','delta [m]')]
    for cell,idx,title,ylabel in panels:
        p=fig.add_subplot(cell);axstyle(p);p.plot(t,data[:,idx],color='#5eead4' if idx!=8 else '#fbbf24',lw=1.2)
        p.set(title=title,xlabel='t [ms]',ylabel=ylabel)
    fig.suptitle('INTERSPACE  /  NUMERICAL IMPACT WORKSTATION  /  STAGE 12',fontsize=15,color='#e5e7eb',fontfamily='monospace',x=.05,ha='left')
    fig.text(.05,.025,'m xddot = F_internal + F_contact    |    U = 1/2 k (l-l0)^2    |    E0 = K_proj + K_nodes + U + Q + r_E',color='#9ca3af',fontsize=10,family='monospace')
    fig.savefig(out/'engineering_console.png',dpi=160,facecolor=fig.get_facecolor());plt.close(fig)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
