import numpy as np
from interspace.deployment import DeploymentConfig, quintic, simulate
from interspace.hemisphere import DomeConfig

def small(dt=0.0002):
    return DeploymentConfig(dome=DomeConfig(rings=3,sectors=6),dt_s=dt)

def test_quintic_endpoints():
    assert np.allclose(quintic(0),[0,0,0]);assert np.allclose(quintic(1),[1,0,0])

def test_deployment_finishes():
    r=simulate(small());assert np.isclose(r['final_fraction'],1)
    assert np.allclose(r['deployed'][:,-1].max(),0.25)

def test_positive_work_and_finite_power():
    r=simulate(small());assert r['history'][-1,5]>0
    assert np.isfinite(r['history']).all()

def test_energy_residual_converges():
    a=simulate(small(0.0004));b=simulate(small(0.0002))
    assert abs(b['history'][-1,-1])<abs(a['history'][-1,-1])

def test_power_limit_is_enforced_as_flag():
    c=small(); c=DeploymentConfig(dome=c.dome,dt_s=c.dt_s,max_total_power_W=0)
    assert not simulate(c)['power_limit_pass']
