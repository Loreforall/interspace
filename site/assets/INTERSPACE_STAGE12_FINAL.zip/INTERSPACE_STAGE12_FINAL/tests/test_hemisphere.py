import numpy as np
from interspace.hemisphere import DomeConfig,mesh,internal,run

def test_hemisphere_boundary():
    p,e,r,f=mesh(DomeConfig(rings=4,sectors=8))
    assert f.sum()==8
    assert np.allclose(p[f,2],0,atol=1e-14)
    assert np.allclose(np.linalg.norm(p,axis=1),.25,atol=1e-14)

def test_rest_forces():
    cfg=DomeConfig(rings=4,sectors=8)
    p,e,r,f=mesh(cfg)
    force,elastic,heat=internal(p,np.zeros_like(p),e,r,cfg.stiffness,cfg.damping)
    assert np.max(abs(force))<1e-9 and elastic<1e-18 and heat==0

def test_zero_impact_no_change():
    cfg=DomeConfig(rings=4,sectors=8,impact_speed=0.,duration=.001)
    out=run(cfg)
    assert np.max(np.abs(out['positions']-out['initial']))<1e-10

def test_finite_collision_and_energy():
    cfg=DomeConfig(rings=4,sectors=8,duration=.004)
    out=run(cfg)
    assert np.all(np.isfinite(out['history']))
    assert np.min(out['history'][:,2])<0
    assert out['max_abs_energy_residual_J']<0.02*out['initial_energy_J']
