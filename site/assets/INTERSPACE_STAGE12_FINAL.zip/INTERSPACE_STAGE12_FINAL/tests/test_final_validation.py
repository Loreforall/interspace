from dataclasses import replace
import numpy as np
import pytest
from interspace.final_validation import CoupledConfig, run, deployment_scan, matched_study
from interspace.hemisphere import DomeConfig

def small():
    return CoupledConfig(dome=DomeConfig(rings=4,sectors=10,duration=.003,dt=5e-6),sample_every=10)

def test_3d_contact_finite():
    o=run(small()); assert np.isfinite(o['history']).all(); assert o['max_abs_energy_residual_J']<.01

def test_storage_bound():
    c=replace(small(),storage_capacity_J=1e-9)
    o=run(c); assert 0<=o['stored_J']<=c.storage_capacity_J+1e-15

def test_zero_coupling_no_storage():
    o=run(replace(small(),coupling_N_per_V=0));assert o['stored_J']==0

def test_invalid_config():
    with pytest.raises(ValueError):run(replace(small(),conversion_efficiency=1.1))

def test_scan_reports_limits():
    a=deployment_scan(times=(.08,));assert 'within_limits' in a[0]

def test_flat_matched_reference():
    rows=matched_study(small(),sectors=(10,),dt_factors=(1,),geometries=('flat',),couplings=(0.,))
    assert rows[0]['status']=='simulated' and np.isfinite(rows[0]['stored_J'])
