from dataclasses import replace
import numpy as np
import pytest
from interspace.hemisphere import DomeConfig
from interspace.transport3d import TransportConfig
from interspace.stage10_extended import StorageConfig,run
from interspace.stage11 import study,convergence_pairs

def cfg(): return TransportConfig(dome=DomeConfig(rings=4,sectors=12,duration=.006,dt=1e-5),impact_phi=.3)

def test_storage_partition():
    r=run(cfg(),StorageConfig(efficiency=.65,capacity_J=.001))
    assert r['storage_partition_residual_J']<1e-12
    assert r['stored_energy_J']<=.001

def test_capacity_and_zero_efficiency():
    a=run(cfg(),StorageConfig(efficiency=0))
    b=run(cfg(),StorageConfig(efficiency=1,capacity_J=1e-10))
    assert a['stored_energy_J']==0
    assert b['stored_energy_J']<=1e-10+1e-16
    assert b['overflow_J']>=0

def test_invalid_storage():
    with pytest.raises(ValueError):run(cfg(),StorageConfig(efficiency=1.2))

def test_study_and_convergence():
    rows=study(cfg(),angles=(0.,.4),couplings=(0.,.004),dt_factors=(1.,.5))
    assert len(rows)==8
    assert len(convergence_pairs(rows))==4
    assert all(np.isfinite(r['max_energy_residual_J']) for r in rows)
