import numpy as np
from interspace import Parameters, make_lattice, forces_and_potential, diagnostics, simulate

def test_equilibrium_lattice():
    s=make_lattice(projectile_x=-5)
    f,_=forces_and_potential(s)
    assert np.max(abs(f)) < 1e-12

def test_force_gradient():
    s=make_lattice(nx=3,ny=3,projectile_x=-.5)
    f,_=forces_and_potential(s)
    eps=1e-6
    for idx in [(0,0),(4,1),(9,0)]:
        s.positions[idx]+=eps
        ep=forces_and_potential(s)[1]
        s.positions[idx]-=2*eps
        em=forces_and_potential(s)[1]
        s.positions[idx]+=eps
        assert np.isclose(f[idx],-(ep-em)/(2*eps),atol=1e-6)

def test_conservation():
    s=make_lattice(nx=5,ny=5,projectile_x=-1.0,projectile_speed=1.0)
    rec,_=simulate(s,duration=1.5,dt=.0005,sample_every=20)
    energy=np.array([r['total_energy'] for r in rec]); momentum=np.array([[r['momentum_x'],r['momentum_y']] for r in rec])
    assert np.max(abs(energy-energy[0])) < 0.005
    assert np.max(abs(momentum-momentum[0])) < 1e-9

def test_timestep_refinement():
    def final(dt):
        s=make_lattice(nx=4,ny=4,projectile_x=-.9,projectile_speed=.7)
        simulate(s,duration=.8,dt=dt,sample_every=100)
        return s.positions.copy()
    coarse=final(.002); medium=final(.001); fine=final(.0005)
    assert np.linalg.norm(medium-fine) < np.linalg.norm(coarse-medium)

def test_zero_initial_momentum():
    s=make_lattice(projectile_speed=0)
    d=diagnostics(s)
    assert d['momentum_x']==0 and d['momentum_y']==0
