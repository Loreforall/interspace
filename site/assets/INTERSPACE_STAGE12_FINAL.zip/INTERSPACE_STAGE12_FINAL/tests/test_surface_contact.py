import numpy as np
from interspace.surface_contact import triangles,closest_triangle,contact

def test_triangles_count():
    assert len(triangles(9,24))==24*(2*9-1)

def test_barycentric_inside():
    p,w=closest_triangle(np.array([.2,.3,1.]),np.array([0.,0.,0.]),np.array([1.,0.,0.]),np.array([0.,1.,0.]))
    assert np.allclose(p,[.2,.3,0.]);assert np.allclose(w,[.5,.2,.3])

def test_vertex_edge_regions():
    a=np.array([0.,0.,0.]);b=np.array([1.,0.,0.]);c=np.array([0.,1.,0.])
    assert np.allclose(closest_triangle(np.array([-1.,-1.,0.]),a,b,c)[1],[1,0,0])
    assert np.allclose(closest_triangle(np.array([.5,-1.,0.]),a,b,c)[1],[.5,.5,0])

def test_contact_momentum_and_potential_gradient():
    p=np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]])
    v=np.zeros_like(p);face=np.array([[0,1,2]])
    center=np.array([.2,.3,.08]);radius=.1;k=100.
    f,fp,u,h,o,_=contact(p,v,face,center,np.zeros(3),radius,k)
    assert np.allclose(f.sum(axis=0)+fp,0,atol=1e-12)
    assert np.isclose(u,.5*k*.02**2)
    eps=1e-6
    plus=contact(p,v,face,center+np.array([0,0,eps]),np.zeros(3),radius,k)[2]
    minus=contact(p,v,face,center-np.array([0,0,eps]),np.zeros(3),radius,k)[2]
    assert np.isclose(fp[2],-(plus-minus)/(2*eps),rtol=1e-8)

def test_contact_no_overlap():
    p=np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]])
    out=contact(p,np.zeros_like(p),np.array([[0,1,2]]),np.array([.2,.3,.5]),np.zeros(3),.1,100.)
    assert np.allclose(out[0],0);assert out[2]==0

def test_contact_damping_nonnegative():
    p=np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]])
    out=contact(p,np.zeros_like(p),np.array([[0,1,2]]),np.array([.2,.3,.08]),np.array([0.,0.,-1.]),.1,100.,2.)
    assert np.isclose(out[3],2.)
