import numpy as np
import pytest
from interspace.impact import ImpactConfig,build,bond_metrics,run_impact

def test_defects_reproducible():
    c=ImpactConfig(defect_fraction=.2,seed=9)
    assert np.array_equal(build(c).bonds,build(c).bonds)
    assert len(build(c).bonds)<len(build(ImpactConfig()).bonds)

def test_zero_strain_at_start():
    s=build(); m=bond_metrics(s,s.positions.copy())
    assert m['max_absolute_strain']==0

def test_impact_energy_and_momentum():
    r,summary,_=run_impact(ImpactConfig(nx=5,ny=5,duration=2,dt=.0005))
    assert summary['max_abs_energy_error']<1e-3
    assert summary['max_momentum_error']<1e-9
    assert summary['peak_pair_contact_force']>0

def test_collision_transfers_kinetic_energy():
    r,summary,_=run_impact(ImpactConfig(nx=5,ny=5,duration=2,dt=.0005))
    assert summary['peak_lattice_displacement']>0
    assert summary['final_lattice_kinetic']>0

def test_invalid_defects():
    with pytest.raises(ValueError):build(ImpactConfig(defect_fraction=1.1))

def test_repeatable_trajectory():
    cfg=ImpactConfig(nx=4,ny=4,duration=.5,dt=.001,defect_fraction=.1)
    a,sa,_=run_impact(cfg);b,sb,_=run_impact(cfg)
    assert sa==sb
    assert a==b
