import numpy as np
import pytest
from interspace.adaptive import AdaptiveConfig,run_adaptive

@pytest.mark.parametrize('mode',['passive','fixed','adaptive'])
def test_energy_and_momentum(mode):
    rows,_=run_adaptive(AdaptiveConfig(mode=mode,duration=1.5))
    assert max(abs(r['energy_residual']) for r in rows)<2e-4
    assert max(r['momentum_residual'] for r in rows)<1e-9
    assert all(r['stored']>=0 and r['heat']>=0 for r in rows)

def test_capacity_saturation_reduces_loading():
    small,_=run_adaptive(AdaptiveConfig(mode='fixed',capacity=0.001,duration=4))
    large,_=run_adaptive(AdaptiveConfig(mode='fixed',capacity=10,duration=4))
    assert small[-1]['stored']<=0.001+1e-12
    assert small[-1]['stored']>0
    assert abs(small[-1]['projectile_x']-large[-1]['projectile_x'])>1e-5

def test_controller_bounds():
    cfg=AdaptiveConfig(mode='adaptive',duration=2)
    rows,_=run_adaptive(cfg)
    assert all(0<=r['damping']<=cfg.max_damping for r in rows)
    assert all(b['stored']>=a['stored'] for a,b in zip(rows,rows[1:]))

def test_invalid_inputs():
    with pytest.raises(ValueError):run_adaptive(AdaptiveConfig(capacity=-1))
