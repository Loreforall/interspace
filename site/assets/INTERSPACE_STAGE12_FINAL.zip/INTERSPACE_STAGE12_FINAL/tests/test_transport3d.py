from dataclasses import replace
import numpy as np
from interspace.transport3d import TransportConfig, run
from interspace.hemisphere import DomeConfig

def small(**kw):
    return TransportConfig(dome=DomeConfig(rings=4,sectors=12,duration=.006,dt=5e-6),**kw)

def test_off_axis_nodes_differ():
    a=run(small(impact_phi=0.0)); b=run(small(impact_phi=.6))
    assert a['impact_node']!=b['impact_node']
    assert a['support_transducers']>0

def test_energy_ledger():
    r=run(small(impact_phi=.4))
    assert r['max_abs_energy_residual_J']<.002
    assert r['load_energy_J']>=0
    assert np.all(np.isfinite(r['history']))

def test_no_coupling_zero_electricity():
    r=run(small(coupling_N_per_V=0))
    assert r['load_energy_J']==0
    assert np.all(r['history'][:,7]==0)

def test_invalid_configuration():
    import pytest
    with pytest.raises(ValueError):run(small(capacitance_F=0))
    with pytest.raises(ValueError):run(small(impact_phi=np.pi/2))

def test_timestep_refinement():
    a=run(small(impact_phi=.35))
    b=run(replace(small(impact_phi=.35),dome=replace(small().dome,dt=2.5e-6)))
    assert b['max_abs_energy_residual_J']<a['max_abs_energy_residual_J']*1.5
