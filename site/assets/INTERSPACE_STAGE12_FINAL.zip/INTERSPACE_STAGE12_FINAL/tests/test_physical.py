import numpy as np
import pytest
from interspace.physical import PhysicalParameters, run

def test_energy_balance():
    out=run(duration_s=.02)
    assert out['max_relative_energy_residual']<1e-7

def test_no_coupling_no_harvest():
    out=run(PhysicalParameters(coupling_n_v=0),duration_s=.02)
    assert out['states'][-1,3]==0

def test_no_damping_no_heat():
    out=run(PhysicalParameters(damping_ns_m=0),duration_s=.02)
    assert out['states'][-1,4]==0
    assert out['states'][-1,5]==0

def test_no_dissipation_conservative():
    p=PhysicalParameters(damping_ns_m=0,coupling_n_v=0)
    out=run(p,duration_s=.02)
    assert abs(out['energy_j'][-1]-out['energy_j'][0])<1e-9

def test_harvest_nonnegative():
    out=run(duration_s=.02)
    assert out['states'][-1,3]>0
    assert np.min(np.diff(out['states'][:,3]))>=-1e-14

def test_refinement():
    a=run(duration_s=.01,dt_s=8e-6)
    b=run(duration_s=.01,dt_s=4e-6)
    c=run(duration_s=.01,dt_s=2e-6)
    assert np.linalg.norm(c['states'][-1,:3]-b['states'][-1,:3]) < np.linalg.norm(b['states'][-1,:3]-a['states'][-1,:3])

def test_invalid_parameters():
    with pytest.raises(ValueError): PhysicalParameters(capacitance_f=0)
