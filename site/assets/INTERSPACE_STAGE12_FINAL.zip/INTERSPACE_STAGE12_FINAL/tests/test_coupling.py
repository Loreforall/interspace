import numpy as np
from interspace.core import Parameters,make_lattice
from interspace.impact import ImpactConfig
from interspace.coupling import CouplingConfig,coupling_terms,run_coupled,envelope

def test_zero_stiffness():
    state=make_lattice();f,u,p=coupling_terms(state,state.positions.copy(),CouplingConfig(stiffness=0))
    assert np.allclose(f,0) and u==0 and p==0

def test_coupling_pair_forces_cancel():
    state=make_lattice();ref=state.positions.copy();state.positions[0,0]+=.2;state.time=.3
    f,u,p=coupling_terms(state,ref,CouplingConfig())
    assert np.linalg.norm(f.sum(axis=0))<1e-12 and u>0

def test_finite_difference_force():
    state=make_lattice();ref=state.positions.copy();state.positions[0,0]+=.1;state.time=.3
    cfg=CouplingConfig();f,_,_=coupling_terms(state,ref,cfg)
    h=1e-6;state.positions[0,0]+=h;up=coupling_terms(state,ref,cfg)[1]
    state.positions[0,0]-=2*h;down=coupling_terms(state,ref,cfg)[1]
    assert np.isclose(f[0,0],-(up-down)/(2*h),rtol=1e-6,atol=1e-8)

def test_envelope_edges():
    cfg=CouplingConfig();assert envelope(-1,cfg)==(0,0)
    assert envelope(.25,cfg)[0]>0
    assert envelope(1,cfg)==(1,0)
    assert envelope(20.5,cfg)==(0,0)

def test_energy_balance_and_momentum():
    _,s,_=run_coupled(ImpactConfig(duration=2,dt=.001,sample_every=10),CouplingConfig())
    assert s['max_abs_energy_balance_residual']<1e-3
    assert s['max_momentum_error']<1e-9

def test_refinement_reduces_energy_residual():
    a=run_coupled(ImpactConfig(duration=1.6,dt=.002,sample_every=1))[1]
    b=run_coupled(ImpactConfig(duration=1.6,dt=.001,sample_every=1))[1]
    assert b['max_abs_energy_balance_residual']<a['max_abs_energy_balance_residual']
