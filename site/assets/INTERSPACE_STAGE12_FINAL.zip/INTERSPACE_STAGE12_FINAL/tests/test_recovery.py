import numpy as np
import pytest
from interspace.core import make_lattice
from interspace.recovery import RecoveryConfig, dashpot_forces, run_recovery

def test_dashpots_conserve_linear_momentum():
    s=make_lattice(nx=3,ny=3)
    s.velocities[:-1]=np.random.default_rng(4).normal(size=(9,2))
    f,p=dashpot_forces(s,2.0)
    assert np.linalg.norm(f.sum(axis=0))<1e-12
    assert p>=0

def test_no_damping_no_storage():
    r,_=run_recovery(RecoveryConfig(damping=0,duration=.4))
    assert r[-1]['stored']==r[-1]['heat']==0

def test_conservation_and_storage():
    r,_=run_recovery(RecoveryConfig(duration=3.0))
    assert max(abs(x['energy_residual']) for x in r)<1e-3
    assert max(x['momentum_residual'] for x in r)<1e-10
    assert r[-1]['stored']>0
    assert r[-1]['heat']>0

def test_full_capacity_routes_to_heat():
    r,_=run_recovery(RecoveryConfig(duration=3,capacity=0.0001))
    assert r[-1]['stored']==pytest.approx(0.0001)
    assert r[-1]['heat']>0

def test_invalid_config():
    with pytest.raises(ValueError): run_recovery(RecoveryConfig(efficiency=1.1))
