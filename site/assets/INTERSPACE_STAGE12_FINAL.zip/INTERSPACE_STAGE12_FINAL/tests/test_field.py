import numpy as np
from dataclasses import replace
from interspace.field import FieldConfig, interaction, simulate_field, required_field_for_energy

def test_force_is_negative_potential_gradient():
    cfg=FieldConfig()
    x=0.4e-9; h=1e-13
    f,_,_=interaction(x,0,cfg)
    numeric=-(interaction(x+h,0,cfg)[1]-interaction(x-h,0,cfg)[1])/(2*h)
    assert np.isclose(f,numeric,rtol=1e-7)

def test_static_conservation():
    rows,summary=simulate_field(FieldConfig(duration_s=2e-11,dt_s=2e-15))
    assert summary['max_abs_energy_residual_j'] < 1e-6*summary['initial_kinetic_j']
    assert summary['net_source_work_j']==0

def test_time_dependent_work():
    cfg=FieldConfig(ramp_s=8e-12,duration_s=2e-11)
    rows,summary=simulate_field(cfg)
    assert abs(summary['net_source_work_j'])>0
    assert summary['max_abs_energy_residual_j'] < 2e-5*summary['initial_kinetic_j']

def test_zero_field_free_particle():
    cfg=FieldConfig(amplitude_v_m=0,duration_s=2e-11)
    rows,s=simulate_field(cfg)
    assert np.isclose(rows[-1]['x_m'],cfg.initial_x_m+cfg.initial_speed_m_s*rows[-1]['time_s'],atol=1e-20)
    assert s['max_force_n']==0

def test_required_field_scaling():
    cfg=FieldConfig()
    e=0.5*cfg.particle_mass_kg*cfg.initial_speed_m_s**2
    E=required_field_for_energy(cfg.alpha_si,e)
    assert np.isclose(0.5*cfg.alpha_si*E**2,e)
